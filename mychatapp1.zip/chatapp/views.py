 
import subprocess
from django.shortcuts import render, redirect
 
from chatapp.forms import ChatMessageForm
from .models import ChatMessage

from django.utils import timezone
import cohere
import getpass
import os
from langchain_cohere import ChatCohere
os.environ["COHERE_API_KEY"] = "oef7WXPGxfMecqTtsvR5OHaFORkxC9UqH9YGJPZn"

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.prompts import FewShotChatMessagePromptTemplate

chat_model = ChatCohere()

topic='default_topic' 
API_KEY = 'oef7WXPGxfMecqTtsvR5OHaFORkxC9UqH9YGJPZn'
co = cohere.Client(API_KEY)

system='default_system'
def getoposite(message):
  
      # Ensure that `message` is the content (string) rather than a ChatMessage object
  
    print("pre",message)
    
    example_prompt = ChatPromptTemplate.from_messages(
    [("human", "{question}"),
     ("ai", "{answer}")
    ]
)
    
    examples = [
    {
        "question": "خوشحال",
        "answer": "ناراحت"
    },
    {
        "question": "مادر",
        "answer": "مهربان"
    },
    {
        "question": "روز",
        "answer": "خورشید"
    },
    ]
    example_prompt = ChatPromptTemplate.from_messages(
    [("human", "{question}"),
     ("ai", "{answer}")
    ]
)
    without_few_shot = ChatPromptTemplate.from_messages(
    [(  "system", "get opposite of word"),
        ("human", "{question}")
    ]
)
    few_shot_prompt = FewShotChatMessagePromptTemplate(
    example_prompt=example_prompt,
    examples=examples,
)

    final_prompt_with_few_shot = ChatPromptTemplate.from_messages(
    [(  "system", "get opposite of word"),
     few_shot_prompt,
     ("human", "{question}")
    ]
)
    chain_with_few_shot = final_prompt_with_few_shot | chat_model


    chat_ai = chain_with_few_shot.invoke({"question": message})
    
 

    # Return the content of the AI response
    return chat_ai.content
def getsense(message):
  
      # Ensure that `message` is the content (string) rather than a ChatMessage object
  
    print("pre",message)
    
    example_prompt = ChatPromptTemplate.from_messages(
    [("human", "{question}"),
     ("ai", "{answer}")
    ]
)
    
    examples = [
    {"question": "من عاشق این فیلمم!", 
     "answer":  "positive"},
    {"question": "از این صندلی خوشم نمی‌اد",
     "answer":  "negative"}
    ]
    example_prompt = ChatPromptTemplate.from_messages(
    [("human", "{question}"),
     ("ai", "{answer}")
    ]
)
    without_few_shot = ChatPromptTemplate.from_messages(
    [(  "system", "احساس متن زیر رو دسته بندی کن"),
        ("human", "{question}")
    ]
)
    few_shot_prompt = FewShotChatMessagePromptTemplate(
    example_prompt=example_prompt,
    examples=examples,
)

    final_prompt_with_few_shot = ChatPromptTemplate.from_messages(
    [(  "system", "احساس متن زیر رو دسته بندی کن"),
     few_shot_prompt,
     ("human", "{question}")
    ]
)
    chain_with_few_shot = final_prompt_with_few_shot | chat_model


    chat_ai = chain_with_few_shot.invoke({"question": message})
    
 

    # Return the content of the AI response
    return chat_ai.content

def chatwithllm(message, topic='default_topic', system='default_system'):
    """
    Run the plasec.py script with the given arguments and system prompt.
    """
    try:
        

        # Run plasec.py with the message, topic, and system prompt
        result = subprocess.run(
            ['python3', 'scripts/plasec.py', message, topic, system],
            capture_output=True,
            text=True
        )

        return result.stdout.strip()  # Return the output from the script
    except Exception as e:
        print(f"Error running script: {str(e)}")
        return f"Error running script: {str(e)}"
       
def search_messages(request):
    query = request.GET.get('q')
    if query:
        results = ChatMessage.objects.filter(content__icontains=query)
        for message in results:
            ChatMessage.score += 1  # Increment score by 1 when message appears in search
            ChatMessage.save()
    return render(request, 'search_results.html', {'messages': results})
def message_clicked(request, message_id):
    try:
        message = ChatMessage.objects.get(id=message_id)
        ChatMessage.score += 10  # Increment score by 10 when clicked
        ChatMessage.save()
        return JsonResponse({'status': 'success', 'new_score': message.score})
    except ChatMessage.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Message not found'})
def run_cal_script(a, b, op):
    """
    Run the cal.py script with the given arguments.
    """
    try:
        # Command to run cal.py with the arguments
        result = subprocess.run(
            ['python3', 'scripts/cal.py', str(a), str(b), op],
            capture_output=True,
            text=True
        )
        return result.stdout.strip()  # Return the output from the script
    except Exception as e:
        return f"Error running script: {str(e)}"

def run_hi_script():
    try:
        # Command to run cal.py with the arguments
        result = subprocess.run(
            ['python3', 'scripts/hi.py'],
            capture_output=True,
            text=True
        )
        return result.stdout.strip()  # Return the output from the script
    except Exception as e:
        return f"Error running script: {str(e)}"
 
def chat_view(request):
    global topic
    global system
    form = ChatMessage()
    messages = ChatMessage.objects.all().order_by('-timestamp')

    if request.method == 'POST':
        form = ChatMessageForm(request.POST)
        if form.is_valid():
            user_message = form.cleaned_data['message']
            try:
                # Handle "cal" command (e.g., "cal 12 23 sum")
                if user_message.startswith("cal"):
                    tokens = user_message.split()
                    if len(tokens) == 4:
                        # Extract arguments and run cal.py
                        num1 = tokens[1]
                        num2 = tokens[2]
                        operation = tokens[3]
                        result = run_cal_script(num1, num2, operation)
                    else:
                        result = "Invalid format. Use: cal <num1> <num2> <operation>"
                elif user_message.startswith("hi"):
                          
                        result = run_hi_script()
                elif user_message.strip() == "$sense":
                    # Fetch the most recent message
                    previous_message = ChatMessage.objects.last()
                    previous_message=previous_message.message+previous_message.response
                    if previous_message:
                        result =getsense(previous_message)  # You can replace this with actual sense analysis logic
                    else:
                        result = "add message after $sense"
                elif user_message.startswith("$oposite "):
                    # Analyze the content after "$sense"
                    sense_content = user_message.replace("$oposite ", "", 1)
                    result = getoposite(sense_content)  # Replace this with actual sense analysis    
                elif user_message.strip() == "$oposite":
                    # Fetch the most recent message
                    previous_message = ChatMessage.objects.last()
                    previous_message=previous_message.message+previous_message.response
                    if previous_message:
                        result =getoposite(previous_message)  # You can replace this with actual sense analysis logic
                    else:
                        result = "add message after $sense"
                elif user_message.startswith("$sense "):
                    # Analyze the content after "$sense"
                    sense_content = user_message.replace("$sense ", "", 1)
                    result = getsense(sense_content)     
                elif   user_message.startswith("$chat"):
                   user_message=user_message.replace("$chat","")
                   result=chatwithllm(user_message,topic,system)
                
                elif   user_message.startswith("$topic"):
                   user_message=user_message.replace("$topic ","")
                   topic=user_message 
                   ChatMessage.topic=topic
                     
                   result="topic is"+topic 
                   
                elif   user_message.startswith("$system"):
                   user_message=user_message.replace("$system","")
                   ChatMessage.system=system

                   system=user_message
                   result="system is"+user_message
                else:
                   result = "Command not recognized."
            except Exception as e:
                result = f"Error: {str(e)}"
            
            # Save the message and response to the database
            ChatMessage.objects.create(
                message=user_message,
                response=result,
                timestamp=timezone.now(),
                topic=topic, 
                system=system,
                score=0,
            )
            return redirect('chatapp:chat')

    return render(request, 'chatapp/chat.html', {'form': form, 'messages': messages})
