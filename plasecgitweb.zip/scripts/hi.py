# mychatapp/scripts/hi.py
def main():
    print("Hello fromm hi.py")
if __name__ == "__main__" :
  main()