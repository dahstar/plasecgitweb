# mychatapp/scripts/hi.py
def main():
    print("Hello from hi.py")
